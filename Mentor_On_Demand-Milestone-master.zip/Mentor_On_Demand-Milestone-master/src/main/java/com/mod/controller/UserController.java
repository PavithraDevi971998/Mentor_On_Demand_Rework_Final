package com.mod.controller;

public interface UserController {

}
