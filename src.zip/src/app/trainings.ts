export class Trainings {
    id:number;
    user_id:string;
    mentor_id:number;
    skill_id:string;
    status:string;
    progress:string;
    rating:number;
    username:string;
    training_name:string;
    mentor_name:string;
    start_date:string;
    end_date:string;
    start_time:string;
    end_time:string;
    amount_received:string;
}
