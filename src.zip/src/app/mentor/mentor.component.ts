import { Component, OnInit, Input } from '@angular/core';
import { Technologies } from '../technologies';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {
  mentor:Mentor;
  mentor1:Mentor;
  username:string;
  password:string;

  constructor(private mentorService:MentorService) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log("submit mentor")
      this.mentorService.getMentor(this.username,this.password)
         .subscribe((data:Mentor)=>{console.log(data)
        this.createUser(data)});
      
  }

  createUser(data:Mentor){
    this.mentor1=data;
    window.localStorage.setItem("mentor",this.mentor1.username);
  }


}
