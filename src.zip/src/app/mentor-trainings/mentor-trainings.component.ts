import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TechnologiesService } from '../technologies.service';
import { Trainings } from '../trainings';

@Component({
  selector: 'app-mentor-trainings',
  templateUrl: './mentor-trainings.component.html',
  styleUrls: ['./mentor-trainings.component.css']
})
export class MentorTrainingsComponent implements OnInit {
  trainings1:Observable<Trainings[]>
  username:string=window.localStorage.getItem("mentor");
  mentor_name:string;
  constructor(private technologiesService:TechnologiesService) { }

  ngOnInit() {
    this.trainings1=this.technologiesService.getMentorAllTrainings(this.username);
  }

  onSubmit(technologies:Trainings){
    this.technologiesService.acceptTrainings(technologies);
  }

}
