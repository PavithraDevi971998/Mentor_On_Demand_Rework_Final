import { Component, OnInit } from '@angular/core';
import { TechnologiesService } from '../technologies.service';
import { Technologies } from '../technologies';
import { Observable } from 'rxjs';
import { TrainingsService } from '../trainings.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  technologies1:Observable<Technologies[]>
  username:string=window.localStorage.getItem("user");
  mentor_name:Observable<string>
  constructor(private technologiesService:TechnologiesService,private trainingsService:TrainingsService) { }

  ngOnInit() {
    console.log(window.localStorage.getItem("user"))
    this.technologies1=this.technologiesService.getTrainings();
  }

  onSubmit(technologies:Technologies){
    this.technologiesService.createUserTraining(technologies,this.username)
      .subscribe((data:Technologies)=>{console.log(data),error=>console.log(error)});
  }
}
