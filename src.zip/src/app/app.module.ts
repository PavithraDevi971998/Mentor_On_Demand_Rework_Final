import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { MentorComponent } from './mentor/mentor.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import {FormsModule} from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { SearchComponent } from './search/search.component';
import { ListTechnologiesComponent } from './list-technologies/list-technologies.component';
import { UserLandingPageComponent } from './user-landing-page/user-landing-page.component';
import { CoursesComponent } from './courses/courses.component';
import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';
import { ProposedTrainingsComponent } from './proposed-trainings/proposed-trainings.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { MentorLandingpageComponent } from './mentor-landingpage/mentor-landingpage.component';
import { MentorTrainingsComponent } from './mentor-trainings/mentor-trainings.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorPaymentsComponent } from './mentor-payments/mentor-payments.component';
import { TrainingProgressComponent } from './training-progress/training-progress.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstPageComponent,
    UserComponent,
    AdminComponent,
    MentorComponent,
    UserRegistrationComponent,
    SearchComponent,
    ListTechnologiesComponent,
    UserLandingPageComponent,
    CoursesComponent,
    UserTrainingsComponent,
    CompletedTrainingsComponent,
    ProposedTrainingsComponent,
    MentorRegistrationComponent,
    MentorLandingpageComponent,
    MentorTrainingsComponent,
    MentorProfileComponent,
    MentorPaymentsComponent,
    TrainingProgressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
