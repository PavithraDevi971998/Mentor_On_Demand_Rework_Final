import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-payments',
  templateUrl: './mentor-payments.component.html',
  styleUrls: ['./mentor-payments.component.css']
})
export class MentorPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
