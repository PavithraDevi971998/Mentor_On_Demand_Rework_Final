import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { MentorComponent } from './mentor/mentor.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { SearchComponent } from './search/search.component';
import { UserLandingPageComponent } from './user-landing-page/user-landing-page.component';
import { CoursesComponent } from './courses/courses.component';
import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { CompletedTrainingsComponent } from './completed-trainings/completed-trainings.component';
import { ProposedTrainingsComponent } from './proposed-trainings/proposed-trainings.component';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { MentorLandingpageComponent } from './mentor-landingpage/mentor-landingpage.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorTrainingsComponent } from './mentor-trainings/mentor-trainings.component';
import { MentorPaymentsComponent } from './mentor-payments/mentor-payments.component';
import { TrainingProgressComponent } from './training-progress/training-progress.component';


const routes: Routes = [
  {path: 'user', component: UserComponent},
  {path: 'admin' , component: AdminComponent},
  {path: 'mentor' , component: MentorComponent},
  {path: 'user/userRegistration' , component:UserRegistrationComponent},
  {path: 'search' , component:SearchComponent},
  {path: 'user/userLanding' , component:UserLandingPageComponent},
  {path: 'courses' , component:CoursesComponent},
  {path: 'allTrainings' , component:UserTrainingsComponent},
  {path: 'completedTrainings' , component:CompletedTrainingsComponent},
  {path: 'proposedTrainings' , component:ProposedTrainingsComponent},
  {path : 'mentor/mentorRegistration' , component:MentorRegistrationComponent},
  {path: 'mentor/mentorLanding' , component:MentorLandingpageComponent},
  {path: 'mentorProfile' ,component:MentorProfileComponent},
  {path :'mentorTrainings' ,component:MentorTrainingsComponent},
  {path :'mentorPayments' ,component:MentorPaymentsComponent},
  {path :'trainingProgress',component:TrainingProgressComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
