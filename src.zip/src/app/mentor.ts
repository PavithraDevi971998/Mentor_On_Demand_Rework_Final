export class Mentor {
    id:number;
    username:string;
    firstname:string;
    password:string;
    lastname:string;
    contact_number:string;
    reg_code:string;
    reg_datetime:string;
    years_of_experience:number;
    linkdein_url:string;
    active:string;
}
